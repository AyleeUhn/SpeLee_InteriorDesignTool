﻿using UnityEngine;
using System.Collections;

namespace GILES.Example
{
	/**
	 *	A simple camera movement controller.
	 */
	public class CameraControls : MonoBehaviour
	{

	}
}
